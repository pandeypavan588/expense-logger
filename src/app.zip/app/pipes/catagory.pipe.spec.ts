import { CatagoryPipe } from './catagory.pipe';

describe('CatagoryPipe', () => {
  it('create an instance', () => {
    const pipe = new CatagoryPipe();
    expect(pipe).toBeTruthy();
  });
});
