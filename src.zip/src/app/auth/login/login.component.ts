import { Component, OnInit } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/auth';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { KeyboardResize, Plugins } from '@capacitor/core';
import { AppRoutes } from 'src/app/constants/constants';
import { AuthService } from '../services/auth/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {

  showPassword = false;

  public loginForm: FormGroup = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.email]),
    password: new FormControl('', [Validators.required, Validators.min(8)])
});

  constructor(
    private authService: AuthService,
        private router: Router,
    ) { 
      Plugins.Device.getInfo().then((deviceInfo) => {
        if (deviceInfo.platform !== 'web') {
            Plugins.Keyboard.setResizeMode({mode: KeyboardResize.None});
            Plugins.Keyboard.addListener('keyboardWillShow', () => {
                console.log('Keyboard Event');
            });
        }
    });
    }

  ngOnInit() {
    
  }

  doLogin(): void {
    this.authService.loginWithEmailAndPassword(this.loginForm.value.email, this.loginForm.value.password)
        .subscribe({
            next: (res) => {
                console.log(res, 'Login Successfull');
                this.router.navigateByUrl(AppRoutes.TABS);
            },
            error: (err) => {
                console.error(err);
            }
        });
}

  togglePasswordFieldType(): void {
    this.showPassword = !this.showPassword;
}

}
