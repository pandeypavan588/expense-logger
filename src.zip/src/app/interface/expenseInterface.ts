export interface ExpenseInterface {
    amount: number;
    description: string;
    type: string;
    createdOn: Date;
}